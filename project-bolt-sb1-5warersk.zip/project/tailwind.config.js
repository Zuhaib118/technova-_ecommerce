/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#f0f4f9',
          100: '#d9e2ef',
          200: '#b3c5df',
          300: '#7d9cc6',
          400: '#4a6fa5',
          500: '#2c4f87',
          600: '#1f3a6b',
          700: '#172d54',
          800: '#112240',
          900: '#0b1a36',
          950: '#070f24',
        },
        brand: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 3px rgba(11,26,54,0.06), 0 1px 2px rgba(11,26,54,0.04)',
        'card-hover': '0 12px 30px -8px rgba(11,26,54,0.18)',
      },
    },
  },
  plugins: [],
};
