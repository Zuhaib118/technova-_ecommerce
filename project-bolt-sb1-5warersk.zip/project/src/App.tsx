import { StoreProvider } from './store';
import { ToastProvider } from './components/Toast';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { useRoute } from './router';
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CartPage } from './pages/CartPage';
import { WishlistPage } from './pages/WishlistPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { FAQPage } from './pages/FAQPage';

function RouteView() {
  const [route] = useRoute();

  switch (route.name) {
    case 'home':
      return <HomePage />;
    case 'shop':
      return <ShopPage />;
    case 'product':
      return <ProductDetailPage />;
    case 'cart':
      return <CartPage />;
    case 'wishlist':
      return <WishlistPage />;
    case 'checkout':
    case 'order-confirmation':
      return <CheckoutPage />;
    case 'about':
      return <AboutPage />;
    case 'contact':
      return <ContactPage />;
    case 'faq':
      return <FAQPage />;
    default:
      return <HomePage />;
  }
}

function App() {
  return (
    <StoreProvider>
      <ToastProvider>
        <div className="flex min-h-screen flex-col bg-white text-navy-900">
          <Header />
          <main className="flex-1">
            <RouteView />
          </main>
          <Footer />
        </div>
      </ToastProvider>
    </StoreProvider>
  );
}

export default App;
