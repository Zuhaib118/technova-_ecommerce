import { useEffect, useState } from 'react';

export type Route =
  | { name: 'home' }
  | { name: 'shop'; category?: string; query?: string }
  | { name: 'product'; id: string }
  | { name: 'cart' }
  | { name: 'wishlist' }
  | { name: 'checkout' }
  | { name: 'order-confirmation' }
  | { name: 'about' }
  | { name: 'contact' }
  | { name: 'faq' };

function parseHash(): Route {
  const hash = window.location.hash.replace(/^#/, '');
  const [path, queryString] = hash.split('?');
  const params = new URLSearchParams(queryString || '');
  const segments = path.split('/').filter(Boolean);

  if (segments.length === 0) return { name: 'home' };
  if (segments[0] === 'shop') {
    return {
      name: 'shop',
      category: params.get('category') || undefined,
      query: params.get('q') || undefined,
    };
  }
  if (segments[0] === 'product' && segments[1]) {
    return { name: 'product', id: segments[1] };
  }
  if (segments[0] === 'cart') return { name: 'cart' };
  if (segments[0] === 'wishlist') return { name: 'wishlist' };
  if (segments[0] === 'checkout') return { name: 'checkout' };
  if (segments[0] === 'order-confirmation') return { name: 'order-confirmation' };
  if (segments[0] === 'about') return { name: 'about' };
  if (segments[0] === 'contact') return { name: 'contact' };
  if (segments[0] === 'faq') return { name: 'faq' };
  return { name: 'home' };
}

export function useRoute(): [Route, (route: Route) => void] {
  const [route, setRouteState] = useState<Route>(() => parseHash());

  useEffect(() => {
    const onHashChange = () => {
      setRouteState(parseHash());
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = (next: Route) => {
    window.location.hash = routeToHash(next);
  };

  return [route, navigate];
}

export function routeToHash(route: Route): string {
  switch (route.name) {
    case 'home':
      return '/';
    case 'shop': {
      const params = new URLSearchParams();
      if (route.category) params.set('category', route.category);
      if (route.query) params.set('q', route.query);
      const qs = params.toString();
      return `/shop${qs ? '?' + qs : ''}`;
    }
    case 'product':
      return `/product/${route.id}`;
    case 'cart':
      return '/cart';
    case 'wishlist':
      return '/wishlist';
    case 'checkout':
      return '/checkout';
    case 'order-confirmation':
      return '/order-confirmation';
    case 'about':
      return '/about';
    case 'contact':
      return '/contact';
    case 'faq':
      return '/faq';
  }
}

export function navigateTo(route: Route) {
  window.location.hash = routeToHash(route);
}
