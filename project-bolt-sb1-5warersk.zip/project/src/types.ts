export type CategoryId =
  | 'smartphones'
  | 'laptops'
  | 'headphones'
  | 'keyboards'
  | 'gaming-accessories'
  | 'smartwatches'
  | 'computer-accessories';

export interface Category {
  id: CategoryId;
  name: string;
  description: string;
  image: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: CategoryId;
  price: number;
  oldPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  gallery: string[];
  inStock: boolean;
  badge?: string;
  description: string;
  specs: { label: string; value: string }[];
  features: string[];
}

export interface CartItem {
  productId: string;
  quantity: number;
}
