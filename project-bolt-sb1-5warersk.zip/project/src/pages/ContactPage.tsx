import { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, MessageSquare } from 'lucide-react';
import { useToast } from '../components/Toast';

export function ContactPage() {
  const { notify } = useToast();
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const update = (field: string, value: string) => {
    setForm((f) => ({ ...f, [field]: value }));
    setErrors((e) => ({ ...e, [field]: '' }));
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!form.name.trim()) next.name = 'Please enter your name';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = 'Enter a valid email';
    if (!form.subject.trim()) next.subject = 'Please add a subject';
    if (form.message.trim().length < 10) next.message = 'Message should be at least 10 characters';
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    notify('Message sent! We will reply within 24 hours.', 'info');
    setForm({ name: '', email: '', subject: '', message: '' });
  };

  const inputClass = (field: string) =>
    `w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition focus:ring-2 ${
      errors[field]
        ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-100'
        : 'border-gray-200 focus:border-brand-400 focus:ring-brand-100'
    }`;

  const contactInfo = [
    { icon: MapPin, label: 'Visit us', value: 'Main Boulevard, Gulberg III, Lahore, Pakistan' },
    { icon: Phone, label: 'Call us', value: '+92 300 1234567' },
    { icon: Mail, label: 'Email us', value: 'support@technova.pk' },
    { icon: Clock, label: 'Hours', value: 'Mon–Sat, 9:00 AM – 8:00 PM' },
  ];

  return (
    <div>
      <section className="bg-navy-900 py-14 text-center text-white">
        <div className="mx-auto max-w-3xl px-4">
          <span className="text-xs font-semibold uppercase tracking-widest text-blue-300">Get in touch</span>
          <h1 className="mt-3 text-3xl font-bold sm:text-4xl">Contact us</h1>
          <p className="mx-auto mt-3 max-w-xl text-sm text-gray-300">
            Questions about a product, your order or a warranty? Our team is here to help.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Info */}
          <div className="space-y-4 lg:col-span-1">
            {contactInfo.map((c) => (
              <div key={c.label} className="flex items-start gap-4 rounded-2xl bg-white p-5 shadow-card ring-1 ring-gray-100">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-blue-50 text-brand-600">
                  <c.icon className="h-5 w-5" />
                </span>
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wide text-gray-500">{c.label}</div>
                  <div className="mt-0.5 text-sm font-medium text-navy-900">{c.value}</div>
                </div>
              </div>
            ))}
            <div className="rounded-2xl bg-gradient-to-br from-brand-600 to-navy-700 p-6 text-white">
              <MessageSquare className="h-6 w-6" />
              <h3 className="mt-3 text-base font-semibold">Live chat coming soon</h3>
              <p className="mt-1 text-xs text-blue-100">
                Until then, drop us a message and we'll respond within 24 hours.
              </p>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-2">
            <form onSubmit={submit} className="rounded-2xl bg-white p-6 shadow-card ring-1 ring-gray-100 sm:p-8">
              <h2 className="text-lg font-bold text-navy-900">Send us a message</h2>
              <p className="mt-1 text-sm text-gray-500">We typically reply within one business day.</p>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">Your name</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => update('name', e.target.value)}
                    placeholder="Ali Khan"
                    className={inputClass('name')}
                  />
                  {errors.name && <p className="mt-1 text-xs text-rose-500">{errors.name}</p>}
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">Email</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => update('email', e.target.value)}
                    placeholder="you@email.com"
                    className={inputClass('email')}
                  />
                  {errors.email && <p className="mt-1 text-xs text-rose-500">{errors.email}</p>}
                </div>
                <div className="sm:col-span-2">
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">Subject</label>
                  <input
                    type="text"
                    value={form.subject}
                    onChange={(e) => update('subject', e.target.value)}
                    placeholder="How can we help?"
                    className={inputClass('subject')}
                  />
                  {errors.subject && <p className="mt-1 text-xs text-rose-500">{errors.subject}</p>}
                </div>
                <div className="sm:col-span-2">
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">Message</label>
                  <textarea
                    rows={5}
                    value={form.message}
                    onChange={(e) => update('message', e.target.value)}
                    placeholder="Tell us more..."
                    className={inputClass('message') + ' resize-none'}
                  />
                  {errors.message && <p className="mt-1 text-xs text-rose-500">{errors.message}</p>}
                </div>
              </div>
              <button
                type="submit"
                className="mt-5 inline-flex items-center gap-2 rounded-xl bg-brand-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 transition hover:bg-brand-500"
              >
                <Send className="h-4 w-4" /> Send message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
