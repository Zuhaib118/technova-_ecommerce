import { ArrowRight, Truck, ShieldCheck, RotateCcw, Headphones, Sparkles } from 'lucide-react';
import { products, categories } from '../data';
import { navigateTo } from '../router';
import { ProductCard } from '../components/ProductCard';
import { CategoryCard } from '../components/CategoryCard';
import { useStore } from '../store';
import { useToast } from '../components/Toast';

export function HomePage() {
  const featured = products.filter((p) => p.badge === 'Best Seller').slice(0, 4);
  const newArrivals = products.filter((p) => p.badge === 'New' || p.badge === 'Creator').concat(products).slice(0, 8);
  const deals = products.filter((p) => p.oldPrice).slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-navy-900">
        <div className="absolute inset-0">
          <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-brand-600/30 blur-3xl" />
          <div className="absolute -bottom-40 left-1/4 h-96 w-96 rounded-full bg-brand-500/20 blur-3xl" />
        </div>
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 lg:grid-cols-2 lg:py-24">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-medium text-blue-200 ring-1 ring-white/15">
              <Sparkles className="h-3.5 w-3.5" /> New 2026 lineup is here
            </span>
            <h1 className="mt-5 text-4xl font-bold leading-tight text-white sm:text-5xl lg:text-6xl">
              Next-gen tech, <br />
              <span className="bg-gradient-to-r from-brand-300 to-brand-500 bg-clip-text text-transparent">
                delivered to your door
              </span>
            </h1>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-gray-300 sm:text-lg">
              Shop the latest smartphones, laptops, audio and gaming gear.
              Genuine products, warranty included, and fast delivery across Pakistan.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <button
                onClick={() => navigateTo({ name: 'shop' })}
                className="group inline-flex items-center gap-2 rounded-xl bg-brand-600 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-brand-600/30 transition hover:bg-brand-500"
              >
                Shop all products
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
              <button
                onClick={() => navigateTo({ name: 'shop', category: 'smartphones' })}
                className="rounded-xl border border-white/20 px-6 py-3.5 text-sm font-semibold text-white transition hover:bg-white/10"
              >
                Explore smartphones
              </button>
            </div>
            <div className="mt-10 flex items-center gap-8">
              {[
                { value: '7+', label: 'Categories' },
                { value: '28+', label: 'Products' },
                { value: '10K+', label: 'Happy customers' },
              ].map((s) => (
                <div key={s.label}>
                  <div className="text-2xl font-bold text-white">{s.value}</div>
                  <div className="text-xs text-gray-400">{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative animate-fade-in">
            <div className="relative grid grid-cols-2 gap-4">
              <img
                src="https://images.pexels.com/photos/7068406/pexels-photo-7068406.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Featured smartphone"
                className="col-span-2 aspect-[16/10] w-full rounded-2xl object-cover shadow-2xl"
              />
              <img
                src="https://images.pexels.com/photos/210927/pexels-photo-210927.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Headphones"
                className="aspect-square w-full rounded-2xl object-cover shadow-xl"
              />
              <img
                src="https://images.pexels.com/photos/267391/pexels-photo-267391.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Smartwatch"
                className="aspect-square w-full rounded-2xl object-cover shadow-xl"
              />
            </div>
            <div className="absolute -bottom-5 -left-5 hidden rounded-xl bg-white p-4 shadow-xl sm:block">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-lg bg-emerald-100 text-emerald-600">
                  <ShieldCheck className="h-5 w-5" />
                </span>
                <div>
                  <div className="text-sm font-semibold text-navy-900">100% Genuine</div>
                  <div className="text-xs text-gray-500">Warranty on every order</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature strip */}
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px overflow-hidden px-4 py-8 lg:grid-cols-4">
          {[
            { icon: Truck, title: 'Free Delivery', sub: 'On orders over Rs 25,000' },
            { icon: ShieldCheck, title: 'Warranty', sub: 'Official brand warranty' },
            { icon: RotateCcw, title: '7-Day Returns', sub: 'Hassle-free returns' },
            { icon: Headphones, title: '24/7 Support', sub: 'Always here to help' },
          ].map((f) => (
            <div key={f.title} className="flex items-center gap-3 px-3 py-2">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-blue-50 text-brand-600">
                <f.icon className="h-5 w-5" />
              </span>
              <div>
                <div className="text-sm font-semibold text-navy-900">{f.title}</div>
                <div className="text-xs text-gray-500">{f.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-14">
        <div className="mb-7 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-bold text-navy-900 sm:text-3xl">Shop by category</h2>
            <p className="mt-1 text-sm text-gray-500">Find exactly what you need across our seven departments.</p>
          </div>
          <button
            onClick={() => navigateTo({ name: 'shop' })}
            className="hidden items-center gap-1 text-sm font-semibold text-brand-600 hover:text-brand-700 sm:inline-flex"
          >
            View all <ArrowRight className="h-4 w-4" />
          </button>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7">
          {categories.map((c) => (
            <CategoryCard key={c.id} image={c.image} name={c.name} id={c.id} />
          ))}
        </div>
      </section>

      {/* Featured / Best sellers */}
      <section className="bg-gray-50 py-14">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-7 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold text-navy-900 sm:text-3xl">Best sellers</h2>
              <p className="mt-1 text-sm text-gray-500">Our most-loved products this month.</p>
            </div>
            <button
              onClick={() => navigateTo({ name: 'shop' })}
              className="hidden items-center gap-1 text-sm font-semibold text-brand-600 hover:text-brand-700 sm:inline-flex"
            >
              View all <ArrowRight className="h-4 w-4" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {featured.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Deals banner */}
      {deals.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-14">
          <div className="mb-7 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold text-navy-900 sm:text-3xl">Hot deals</h2>
              <p className="mt-1 text-sm text-gray-500">Limited-time savings on top gear.</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {deals.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </section>
      )}

      {/* New arrivals */}
      <section className="bg-navy-900 py-14">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-7 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white sm:text-3xl">New arrivals</h2>
              <p className="mt-1 text-sm text-gray-400">Fresh stock just landed.</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {newArrivals.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter CTA */}
      <NewsletterCTA />
    </div>
  );
}

function NewsletterCTA() {
  const { notify } = useToast();
  const { wishlist } = useStore();
  void wishlist;
  return (
    <section className="mx-auto max-w-7xl px-4 py-14">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-600 to-navy-700 px-6 py-12 text-center sm:px-12">
        <div className="absolute -right-20 -top-20 h-60 w-60 rounded-full bg-white/10 blur-2xl" />
        <h2 className="relative text-2xl font-bold text-white sm:text-3xl">Stay in the loop</h2>
        <p className="relative mx-auto mt-3 max-w-md text-sm text-blue-100">
          Subscribe for exclusive deals, new launches and tech tips — straight to your inbox.
        </p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            notify('Thanks for subscribing!', 'info');
            (e.currentTarget as HTMLFormElement).reset();
          }}
          className="relative mx-auto mt-6 flex max-w-md flex-col gap-3 sm:flex-row"
        >
          <input
            type="email"
            required
            placeholder="you@email.com"
            className="flex-1 rounded-xl border-0 px-4 py-3 text-sm text-navy-900 outline-none ring-2 ring-white/20 focus:ring-white"
          />
          <button
            type="submit"
            className="rounded-xl bg-navy-900 px-6 py-3 text-sm font-semibold text-white transition hover:bg-navy-800"
          >
            Subscribe
          </button>
        </form>
      </div>
    </section>
  );
}
