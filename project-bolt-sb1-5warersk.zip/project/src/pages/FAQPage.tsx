import { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { navigateTo } from '../router';

interface QA {
  q: string;
  a: string;
}

const faqGroups: { title: string; items: QA[] }[] = [
  {
    title: 'Orders & Delivery',
    items: [
      {
        q: 'How long does delivery take?',
        a: 'Orders are dispatched within 24 hours and typically arrive in 2–4 business days across major cities in Pakistan. Remote areas may take an extra day or two.',
      },
      {
        q: 'Do you offer free delivery?',
        a: 'Yes — all orders above Rs 25,000 qualify for free standard delivery anywhere in Pakistan. Orders below that threshold carry a flat Rs 500 shipping fee.',
      },
      {
        q: 'Can I track my order?',
        a: 'Once your order is shipped you will receive an SMS and email with a tracking link. Since this is a demo store, no real shipments are dispatched.',
      },
    ],
  },
  {
    title: 'Payments',
    items: [
      {
        q: 'What payment methods do you accept?',
        a: 'We support Cash on Delivery, credit/debit cards and bank transfer. In this demonstration store, no real payment is processed.',
      },
      {
        q: 'Is it safe to pay with my card?',
        a: 'The checkout on this site is for demonstration only and does not transmit card details to any payment processor. No real transaction takes place.',
      },
    ],
  },
  {
    title: 'Returns & Warranty',
    items: [
      {
        q: 'What is your return policy?',
        a: 'You can return unopened items within 7 days of delivery for a full refund. Opened items may be returned if they are faulty and covered by warranty.',
      },
      {
        q: 'Do products come with a warranty?',
        a: 'Every product carries the official brand warranty. Warranty periods vary by manufacturer and are listed in the product specifications.',
      },
    ],
  },
  {
    title: 'Account & Privacy',
    items: [
      {
        q: 'Do I need an account to order?',
        a: 'No account is required. You can checkout as a guest. Your cart and wishlist are saved on your device so they persist between visits.',
      },
      {
        q: 'How is my data protected?',
        a: 'This is a university project demo store. We do not collect or transmit personal data. Any information you enter stays in your browser.',
      },
    ],
  },
];

export function FAQPage() {
  const [open, setOpen] = useState<string | null>(`${faqGroups[0].title}-0`);

  const toggle = (key: string) => setOpen((prev) => (prev === key ? null : key));

  return (
    <div>
      <section className="bg-navy-900 py-14 text-center text-white">
        <div className="mx-auto max-w-3xl px-4">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-white/10 text-blue-300">
            <HelpCircle className="h-7 w-7" />
          </span>
          <h1 className="mt-4 text-3xl font-bold sm:text-4xl">Frequently Asked Questions</h1>
          <p className="mx-auto mt-3 max-w-xl text-sm text-gray-300">
            Everything you need to know about ordering, delivery, payments and returns.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-3xl px-4 py-12">
        <div className="space-y-8">
          {faqGroups.map((group) => (
            <div key={group.title}>
              <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-brand-600">
                {group.title}
              </h2>
              <div className="space-y-2.5">
                {group.items.map((item, i) => {
                  const key = `${group.title}-${i}`;
                  const isOpen = open === key;
                  return (
                    <div
                      key={key}
                      className="overflow-hidden rounded-xl bg-white shadow-card ring-1 ring-gray-100"
                    >
                      <button
                        onClick={() => toggle(key)}
                        className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left"
                      >
                        <span className="text-sm font-semibold text-navy-900">{item.q}</span>
                        <ChevronDown
                          className={`h-4 w-4 shrink-0 text-gray-400 transition-transform ${
                            isOpen ? 'rotate-180' : ''
                          }`}
                        />
                      </button>
                      <div
                        className={`grid transition-all duration-300 ${
                          isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                        }`}
                      >
                        <div className="overflow-hidden">
                          <p className="px-5 pb-4 text-sm leading-relaxed text-gray-600">{item.a}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-2xl bg-gradient-to-br from-brand-600 to-navy-700 p-8 text-center text-white">
          <h2 className="text-lg font-bold">Still have questions?</h2>
          <p className="mt-2 text-sm text-blue-100">Our support team is happy to help.</p>
          <button
            onClick={() => navigateTo({ name: 'contact' })}
            className="mt-5 rounded-xl bg-white px-6 py-3 text-sm font-semibold text-navy-900 transition hover:bg-blue-50"
          >
            Contact us
          </button>
        </div>
      </div>
    </div>
  );
}
