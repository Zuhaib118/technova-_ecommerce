import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, Heart } from 'lucide-react';
import { useStore } from '../store';
import { getProduct, formatPKR } from '../data';
import { navigateTo, useRoute } from '../router';

const SHIPPING_THRESHOLD = 25000;
const SHIPPING_FEE = 500;

export function CartPage() {
  const [route, navigate] = useRoute();
  const { cart, updateQuantity, removeFromCart, cartSubtotal } = useStore();

  const shipping = cartSubtotal >= SHIPPING_THRESHOLD || cartSubtotal === 0 ? 0 : SHIPPING_FEE;
  const total = cartSubtotal + shipping;
  const remaining = Math.max(0, SHIPPING_THRESHOLD - cartSubtotal);

  if (cart.length === 0) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-20">
        <div className="mx-auto max-w-md rounded-3xl bg-white p-10 text-center shadow-card ring-1 ring-gray-100">
          <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-blue-50 text-brand-500">
            <ShoppingBag className="h-9 w-9" />
          </div>
          <h1 className="mt-6 text-xl font-bold text-navy-900">Your cart is empty</h1>
          <p className="mt-2 text-sm text-gray-500">
            Looks like you have not added anything yet. Let's find something you'll love.
          </p>
          <button
            onClick={() => navigate({ name: 'shop' })}
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-500"
          >
            Start shopping <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-[60vh]">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <h1 className="text-2xl font-bold text-navy-900 sm:text-3xl">Shopping Cart</h1>
        <p className="mt-1 text-sm text-gray-500">{cart.length} item{cart.length !== 1 ? 's' : ''} in your cart</p>

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          {/* Items */}
          <div className="lg:col-span-2 space-y-3">
            {cart.map((item) => {
              const product = getProduct(item.productId);
              if (!product) return null;
              return (
                <div
                  key={item.productId}
                  className="flex gap-4 rounded-2xl bg-white p-4 shadow-card ring-1 ring-gray-100 animate-fade-in"
                >
                  <button
                    onClick={() => navigate({ name: 'product', id: product.id })}
                    className="h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-gray-50"
                  >
                    <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
                  </button>

                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span className="text-[11px] font-medium uppercase tracking-wide text-blue-600">
                          {product.brand}
                        </span>
                        <h3 className="text-sm font-semibold text-navy-900">{product.name}</h3>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.productId)}
                        className="grid h-8 w-8 place-items-center rounded-lg text-gray-400 transition hover:bg-rose-50 hover:text-rose-500"
                        aria-label="Remove item"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="mt-auto flex items-end justify-between pt-3">
                      <div className="flex items-center rounded-lg border border-gray-200">
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                          className="grid h-9 w-9 place-items-center text-gray-600 hover:text-brand-600"
                          aria-label="Decrease"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-9 text-center text-sm font-semibold text-navy-900">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                          className="grid h-9 w-9 place-items-center text-gray-600 hover:text-brand-600"
                          aria-label="Increase"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-bold text-navy-900">
                          {formatPKR(product.price * item.quantity)}
                        </div>
                        <div className="text-xs text-gray-400">{formatPKR(product.price)} each</div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}

            <button
              onClick={() => navigate({ name: 'shop' })}
              className="inline-flex items-center gap-2 text-sm font-semibold text-brand-600 hover:text-brand-700"
            >
              <ArrowRight className="h-4 w-4 rotate-180" /> Continue shopping
            </button>
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-28 rounded-2xl bg-white p-6 shadow-card ring-1 ring-gray-100">
              <h2 className="text-base font-bold text-navy-900">Order Summary</h2>

              {remaining > 0 ? (
                <div className="mt-3 rounded-xl bg-blue-50 p-3 text-xs text-blue-800">
                  Add <span className="font-semibold">{formatPKR(remaining)}</span> more to qualify for
                  free delivery.
                </div>
              ) : (
                <div className="mt-3 rounded-xl bg-emerald-50 p-3 text-xs text-emerald-700">
                  You've unlocked free delivery!
                </div>
              )}

              <dl className="mt-4 space-y-2.5 text-sm">
                <div className="flex justify-between">
                  <dt className="text-gray-500">Subtotal</dt>
                  <dd className="font-medium text-navy-900">{formatPKR(cartSubtotal)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-500">Delivery</dt>
                  <dd className="font-medium text-navy-900">
                    {shipping === 0 ? <span className="text-emerald-600">Free</span> : formatPKR(shipping)}
                  </dd>
                </div>
                <div className="border-t border-gray-100 pt-3">
                  <div className="flex justify-between">
                    <dt className="text-base font-bold text-navy-900">Total</dt>
                    <dd className="text-base font-bold text-brand-600">{formatPKR(total)}</dd>
                  </div>
                </div>
              </dl>

              <button
                onClick={() => navigate({ name: 'checkout' })}
                className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 py-3.5 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 transition hover:bg-brand-500"
              >
                Proceed to checkout <ArrowRight className="h-4 w-4" />
              </button>

              <button
                onClick={() => navigate({ name: 'wishlist' })}
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-gray-200 py-3 text-sm font-medium text-navy-800 hover:bg-gray-50"
              >
                <Heart className="h-4 w-4" /> View wishlist
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
