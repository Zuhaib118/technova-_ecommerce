import { Heart, ShoppingBag, ArrowRight, Trash2 } from 'lucide-react';
import { useStore } from '../store';
import { getProduct, formatPKR } from '../data';
import { navigateTo, useRoute } from '../router';
import { useToast } from '../components/Toast';

export function WishlistPage() {
  const [route, navigate] = useRoute();
  const { wishlist, toggleWishlist, addToCart } = useStore();
  const { notify } = useToast();

  const items = wishlist.map((id) => getProduct(id)).filter(Boolean);

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-20">
        <div className="mx-auto max-w-md rounded-3xl bg-white p-10 text-center shadow-card ring-1 ring-gray-100">
          <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-rose-50 text-rose-400">
            <Heart className="h-9 w-9" />
          </div>
          <h1 className="mt-6 text-xl font-bold text-navy-900">Your wishlist is empty</h1>
          <p className="mt-2 text-sm text-gray-500">
            Tap the heart icon on any product to save it here for later.
          </p>
          <button
            onClick={() => navigate({ name: 'shop' })}
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-500"
          >
            Browse products <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-[60vh]">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <h1 className="text-2xl font-bold text-navy-900 sm:text-3xl">My Wishlist</h1>
        <p className="mt-1 text-sm text-gray-500">{items.length} saved item{items.length !== 1 ? 's' : ''}</p>

        <div className="mt-6 space-y-3">
          {items.map((product) => {
            if (!product) return null;
            return (
              <div
                key={product.id}
                className="flex gap-4 rounded-2xl bg-white p-4 shadow-card ring-1 ring-gray-100 animate-fade-in"
              >
                <button
                  onClick={() => navigate({ name: 'product', id: product.id })}
                  className="h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-gray-50"
                >
                  <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
                </button>

                <div className="flex flex-1 flex-col">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[11px] font-medium uppercase tracking-wide text-blue-600">
                        {product.brand}
                      </span>
                      <h3 className="text-sm font-semibold text-navy-900">{product.name}</h3>
                      <p className="mt-1 text-xs text-gray-500 line-clamp-1">{product.description}</p>
                    </div>
                    <button
                      onClick={() => toggleWishlist(product.id)}
                      className="grid h-8 w-8 place-items-center rounded-lg text-rose-500 transition hover:bg-rose-50"
                      aria-label="Remove from wishlist"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="mt-auto flex items-end justify-between pt-3">
                    <div>
                      <span className="text-base font-bold text-navy-900">{formatPKR(product.price)}</span>
                      {product.oldPrice && (
                        <span className="ml-2 text-xs text-gray-400 line-through">
                          {formatPKR(product.oldPrice)}
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => {
                        if (!product.inStock) return;
                        addToCart(product.id);
                        notify(`${product.name} added to cart`);
                      }}
                      disabled={!product.inStock}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-brand-600 px-4 py-2 text-xs font-semibold text-white transition hover:bg-brand-500 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <ShoppingBag className="h-3.5 w-3.5" />
                      {product.inStock ? 'Add to cart' : 'Out of stock'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
