import { useMemo, useState } from 'react';
import { Search, SlidersHorizontal, X, Check } from 'lucide-react';
import { products, categories } from '../data';
import type { CategoryId } from '../types';
import { ProductCard } from '../components/ProductCard';
import { useRoute } from '../router';

type SortKey = 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'name';

export function ShopPage() {
  const [route, navigate] = useRoute();
  const initialCategory = route.name === 'shop' ? route.category : undefined;
  const initialQuery = route.name === 'shop' ? route.query : undefined;

  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(initialCategory);
  const [query, setQuery] = useState(initialQuery || '');
  const [sort, setSort] = useState<SortKey>('featured');
  const [inStockOnly, setInStockOnly] = useState(false);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const filtered = useMemo(() => {
    let list = products.slice();
    if (selectedCategory) {
      list = list.filter((p) => p.category === selectedCategory);
    }
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      );
    }
    if (inStockOnly) list = list.filter((p) => p.inStock);

    switch (sort) {
      case 'price-asc':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        list.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        list.sort((a, b) => b.rating - a.rating);
        break;
      case 'name':
        list.sort((a, b) => a.name.localeCompare(b.name));
        break;
      default:
        list.sort((a, b) => Number(!!b.badge) - Number(!!a.badge));
    }
    return list;
  }, [selectedCategory, query, sort, inStockOnly]);

  const activeCategoryName = selectedCategory
    ? categories.find((c) => c.id === selectedCategory)?.name
    : 'All Products';

  const selectCategory = (id?: string) => {
    setSelectedCategory(id);
    navigate({ name: 'shop', category: id, query: query || undefined });
  };

  const onSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate({ name: 'shop', category: selectedCategory, query: query || undefined });
  };

  const clearAll = () => {
    setSelectedCategory(undefined);
    setQuery('');
    setInStockOnly(false);
    setSort('featured');
    navigate({ name: 'shop' });
  };

  const FilterPanel = () => (
    <div className="space-y-6">
      <div>
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-gray-500">Categories</h3>
        <div className="space-y-1">
          <button
            onClick={() => selectCategory(undefined)}
            className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
              !selectedCategory ? 'bg-blue-50 font-semibold text-brand-700' : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            All Products
            <span className="text-xs text-gray-400">{products.length}</span>
          </button>
          {categories.map((c) => {
            const count = products.filter((p) => p.category === c.id).length;
            const active = selectedCategory === c.id;
            return (
              <button
                key={c.id}
                onClick={() => selectCategory(c.id)}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
                  active ? 'bg-blue-50 font-semibold text-brand-700' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                {c.name}
                <span className="text-xs text-gray-400">{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-gray-500">Availability</h3>
        <label className="flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
          <span
            className={`grid h-5 w-5 place-items-center rounded border transition ${
              inStockOnly ? 'border-brand-600 bg-brand-600 text-white' : 'border-gray-300 bg-white'
            }`}
          >
            {inStockOnly && <Check className="h-3.5 w-3.5" />}
          </span>
          <input
            type="checkbox"
            checked={inStockOnly}
            onChange={(e) => setInStockOnly(e.target.checked)}
            className="sr-only"
          />
          In stock only
        </label>
      </div>
    </div>
  );

  return (
    <div className="bg-gray-50 min-h-[60vh]">
      {/* Page header */}
      <div className="border-b border-gray-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-6">
          <nav className="text-xs text-gray-400">
            <span>Home</span> <span className="mx-1">/</span>{' '}
            <span className="text-gray-700">Shop</span>
            {selectedCategory && (
              <>
                <span className="mx-1">/</span>
                <span className="text-gray-700">{activeCategoryName}</span>
              </>
            )}
          </nav>
          <h1 className="mt-2 text-2xl font-bold text-navy-900 sm:text-3xl">{activeCategoryName}</h1>
          <p className="mt-1 text-sm text-gray-500">
            {filtered.length} {filtered.length === 1 ? 'product' : 'products'} found
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8">
        {/* Search + sort bar */}
        <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
          <form onSubmit={onSearch} className="relative flex-1">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search within results..."
              className="w-full rounded-xl border border-gray-200 bg-white py-2.5 pl-11 pr-4 text-sm outline-none transition focus:border-brand-400 focus:ring-2 focus:ring-brand-100"
            />
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-gray-400" />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </form>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMobileFiltersOpen(true)}
              className="flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-medium text-navy-800 lg:hidden"
            >
              <SlidersHorizontal className="h-4 w-4" /> Filters
            </button>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
              className="rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-medium text-navy-800 outline-none focus:border-brand-400"
            >
              <option value="featured">Featured</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Rated</option>
              <option value="name">Name: A to Z</option>
            </select>
          </div>
        </div>

        <div className="flex gap-8">
          {/* Desktop sidebar */}
          <aside className="hidden w-60 shrink-0 lg:block">
            <div className="sticky top-28 rounded-2xl bg-white p-5 shadow-card ring-1 ring-gray-100">
              <FilterPanel />
            </div>
          </aside>

          {/* Products */}
          <div className="flex-1">
            {filtered.length === 0 ? (
              <div className="grid place-items-center rounded-2xl bg-white py-20 text-center ring-1 ring-gray-100">
                <div>
                  <Search className="mx-auto h-10 w-10 text-gray-300" />
                  <h3 className="mt-4 text-lg font-semibold text-navy-900">No products found</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Try a different search term or clear your filters.
                  </p>
                  <button
                    onClick={clearAll}
                    className="mt-4 rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-500"
                  >
                    Clear filters
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
                {filtered.map((p, i) => (
                  <ProductCard key={p.id} product={p} index={i} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile filter drawer */}
      {mobileFiltersOpen && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div
            className="absolute inset-0 bg-navy-900/50 animate-fade-in"
            onClick={() => setMobileFiltersOpen(false)}
          />
          <div className="absolute left-0 top-0 h-full w-72 max-w-[85%] bg-white p-5 shadow-xl animate-scale-in">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-base font-bold text-navy-900">Filters</h2>
              <button onClick={() => setMobileFiltersOpen(false)} className="text-gray-500">
                <X className="h-5 w-5" />
              </button>
            </div>
            <FilterPanel />
            <button
              onClick={() => setMobileFiltersOpen(false)}
              className="mt-6 w-full rounded-xl bg-brand-600 py-3 text-sm font-semibold text-white"
            >
              Show {filtered.length} results
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
