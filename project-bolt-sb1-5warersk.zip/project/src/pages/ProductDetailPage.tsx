import { useState } from 'react';
import {
  Heart,
  ShoppingCart,
  ChevronRight,
  Check,
  Minus,
  Plus,
  Truck,
  ShieldCheck,
  RotateCcw,
  Share2,
} from 'lucide-react';
import { getProduct, getCategory, formatPKR, products } from '../data';
import { navigateTo, useRoute } from '../router';
import { useStore } from '../store';
import { useToast } from '../components/Toast';
import { StarRating } from '../components/StarRating';
import { ProductCard } from '../components/ProductCard';

export function ProductDetailPage() {
  const [route, navigate] = useRoute();
  const id = route.name === 'product' ? route.id : '';
  const product = getProduct(id);
  const { addToCart, toggleWishlist, isWishlisted } = useStore();
  const { notify } = useToast();
  const [qty, setQty] = useState(1);
  const [activeImage, setActiveImage] = useState(0);

  if (!product) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-24 text-center">
        <h1 className="text-2xl font-bold text-navy-900">Product not found</h1>
        <p className="mt-2 text-gray-500">The product you are looking for does not exist.</p>
        <button
          onClick={() => navigate({ name: 'shop' })}
          className="mt-6 rounded-xl bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-500"
        >
          Back to shop
        </button>
      </div>
    );
  }

  const category = getCategory(product.category);
  const wished = isWishlisted(product.id);
  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  const related = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAdd = () => {
    addToCart(product.id, qty);
    notify(`${qty} × ${product.name} added to cart`);
  };

  const handleBuyNow = () => {
    addToCart(product.id, qty);
    navigate({ name: 'checkout' });
  };

  return (
    <div className="bg-gray-50">
      {/* Breadcrumb */}
      <div className="border-b border-gray-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center gap-1.5 px-4 py-3 text-xs text-gray-400">
          <button onClick={() => navigate({ name: 'home' })} className="hover:text-brand-600">Home</button>
          <ChevronRight className="h-3 w-3" />
          <button onClick={() => navigate({ name: 'shop' })} className="hover:text-brand-600">Shop</button>
          {category && (
            <>
              <ChevronRight className="h-3 w-3" />
              <button
                onClick={() => navigate({ name: 'shop', category: category.id })}
                className="hover:text-brand-600"
              >
                {category.name}
              </button>
            </>
          )}
          <ChevronRight className="h-3 w-3" />
          <span className="text-gray-700">{product.name}</span>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Gallery */}
          <div className="animate-fade-up">
            <div className="relative overflow-hidden rounded-2xl bg-white ring-1 ring-gray-100">
              <img
                src={product.gallery[activeImage]}
                alt={product.name}
                className="aspect-square w-full object-cover"
              />
              {discount > 0 && (
                <span className="absolute left-4 top-4 rounded-full bg-rose-500 px-3 py-1 text-xs font-semibold text-white">
                  -{discount}% OFF
                </span>
              )}
            </div>
            {product.gallery.length > 1 && (
              <div className="mt-4 flex gap-3">
                {product.gallery.map((g, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`h-20 w-20 overflow-hidden rounded-xl ring-2 transition ${
                      activeImage === i ? 'ring-brand-500' : 'ring-transparent hover:ring-gray-200'
                    }`}
                  >
                    <img src={g} alt={`${product.name} ${i + 1}`} className="h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="animate-fade-up" style={{ animationDelay: '80ms' }}>
            <span className="text-xs font-semibold uppercase tracking-wide text-brand-600">
              {product.brand}
            </span>
            <h1 className="mt-1.5 text-2xl font-bold leading-tight text-navy-900 sm:text-3xl">
              {product.name}
            </h1>
            <div className="mt-3 flex items-center gap-3">
              <StarRating rating={product.rating} reviews={product.reviews} size="md" />
              <span
                className={`text-xs font-medium ${
                  product.inStock ? 'text-emerald-600' : 'text-rose-500'
                }`}
              >
                {product.inStock ? 'In stock' : 'Out of stock'}
              </span>
            </div>

            <div className="mt-5 flex items-end gap-3">
              <span className="text-3xl font-bold text-navy-900">{formatPKR(product.price)}</span>
              {product.oldPrice && (
                <span className="text-lg text-gray-400 line-through">{formatPKR(product.oldPrice)}</span>
              )}
            </div>

            <p className="mt-5 text-sm leading-relaxed text-gray-600">{product.description}</p>

            {/* Features */}
            <div className="mt-5 grid grid-cols-2 gap-2">
              {product.features.map((f) => (
                <div key={f} className="flex items-center gap-2 text-sm text-gray-700">
                  <Check className="h-4 w-4 shrink-0 text-emerald-500" />
                  {f}
                </div>
              ))}
            </div>

            {/* Quantity + actions */}
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <div className="flex items-center rounded-xl border border-gray-200 bg-white">
                <button
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="grid h-11 w-11 place-items-center text-gray-600 hover:text-brand-600"
                  aria-label="Decrease quantity"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-10 text-center text-sm font-semibold text-navy-900">{qty}</span>
                <button
                  onClick={() => setQty((q) => q + 1)}
                  className="grid h-11 w-11 place-items-center text-gray-600 hover:text-brand-600"
                  aria-label="Increase quantity"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>

              <button
                onClick={handleAdd}
                disabled={!product.inStock}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-brand-600 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 transition hover:bg-brand-500 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <ShoppingCart className="h-4.5 w-4.5" />
                Add to Cart
              </button>

              <button
                onClick={() => toggleWishlist(product.id)}
                className={`grid h-12 w-12 place-items-center rounded-xl border transition ${
                  wished
                    ? 'border-rose-200 bg-rose-50 text-rose-500'
                    : 'border-gray-200 bg-white text-gray-600 hover:text-rose-500'
                }`}
                aria-label="Toggle wishlist"
              >
                <Heart className={`h-5 w-5 ${wished ? 'fill-rose-500' : ''}`} />
              </button>
            </div>

            {product.inStock && (
              <button
                onClick={handleBuyNow}
                className="mt-3 w-full rounded-xl border-2 border-navy-900 py-3.5 text-sm font-bold text-navy-900 transition hover:bg-navy-900 hover:text-white"
              >
                Buy it now
              </button>
            )}

            {/* Share */}
            <div className="mt-4 flex items-center gap-2 text-sm text-gray-500">
              <button
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({ title: product.name, text: product.description }).catch(() => {});
                  } else {
                    navigator.clipboard?.writeText(window.location.href);
                    notify('Link copied to clipboard', 'info');
                  }
                }}
                className="inline-flex items-center gap-1.5 hover:text-brand-600"
              >
                <Share2 className="h-4 w-4" /> Share
              </button>
            </div>

            {/* Trust badges */}
            <div className="mt-7 grid grid-cols-3 gap-3 border-t border-gray-100 pt-6">
              {[
                { icon: Truck, label: 'Free delivery' },
                { icon: ShieldCheck, label: 'Warranty' },
                { icon: RotateCcw, label: '7-day returns' },
              ].map((t) => (
                <div key={t.label} className="flex flex-col items-center gap-1.5 text-center">
                  <t.icon className="h-5 w-5 text-brand-600" />
                  <span className="text-xs font-medium text-gray-600">{t.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Specs */}
        <div className="mt-12 grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <h2 className="text-xl font-bold text-navy-900">Specifications</h2>
            <div className="mt-4 overflow-hidden rounded-2xl bg-white ring-1 ring-gray-100">
              <table className="w-full text-sm">
                <tbody>
                  {product.specs.map((s, i) => (
                    <tr key={s.label} className={i % 2 === 0 ? 'bg-gray-50/60' : 'bg-white'}>
                      <td className="w-1/3 px-5 py-3.5 font-medium text-gray-600">{s.label}</td>
                      <td className="px-5 py-3.5 text-navy-900">{s.value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold text-navy-900">Description</h2>
            <div className="mt-4 rounded-2xl bg-white p-5 ring-1 ring-gray-100">
              <p className="text-sm leading-relaxed text-gray-600">{product.description}</p>
              {category && (
                <button
                  onClick={() => navigate({ name: 'shop', category: category.id })}
                  className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-600 hover:text-brand-700"
                >
                  More in {category.name} <ChevronRight className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <div className="mt-14">
            <h2 className="text-xl font-bold text-navy-900">You might also like</h2>
            <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {related.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
