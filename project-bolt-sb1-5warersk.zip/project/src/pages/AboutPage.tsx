import { Target, Eye, Award, Users, Truck, ShieldCheck, Heart, Leaf } from 'lucide-react';
import { navigateTo } from '../router';

export function AboutPage() {
  const values = [
    { icon: ShieldCheck, title: 'Genuine Products', desc: 'Every item is sourced from authorized distributors with official warranty.' },
    { icon: Truck, title: 'Fast Delivery', desc: 'We ship across Pakistan with tracked delivery in 2–4 business days.' },
    { icon: Heart, title: 'Customer First', desc: 'A support team that actually helps — before and after your purchase.' },
    { icon: Leaf, title: 'Responsible Tech', desc: 'We recycle packaging and partner with e-waste programs nationwide.' },
  ];

  const stats = [
    { icon: Users, value: '10,000+', label: 'Happy customers' },
    { icon: Award, value: '4.8/5', label: 'Average rating' },
    { icon: Truck, value: '120+', label: 'Cities served' },
    { icon: ShieldCheck, value: '100%', label: 'Genuine products' },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-navy-900 py-16 text-white sm:py-20">
        <div className="absolute -right-32 top-0 h-72 w-72 rounded-full bg-brand-600/30 blur-3xl" />
        <div className="relative mx-auto max-w-4xl px-4 text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-blue-300">About TechNova</span>
          <h1 className="mt-3 text-3xl font-bold sm:text-5xl">
            Tech you can trust, prices you'll love
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-gray-300 sm:text-lg">
            TechNova was founded in 2021 with a simple mission: make the latest electronics
            accessible to everyone in Pakistan — with honest pricing, genuine warranty and
            reliable delivery from Karachi to Peshawar.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="rounded-2xl bg-white p-6 text-center shadow-card ring-1 ring-gray-100">
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-blue-50 text-brand-600">
                <s.icon className="h-6 w-6" />
              </span>
              <div className="mt-3 text-2xl font-bold text-navy-900">{s.value}</div>
              <div className="text-xs text-gray-500">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Mission / Vision */}
      <section className="mx-auto max-w-7xl px-4 py-8">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="rounded-2xl bg-white p-8 shadow-card ring-1 ring-gray-100">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-600 text-white">
              <Target className="h-5 w-5" />
            </span>
            <h2 className="mt-4 text-xl font-bold text-navy-900">Our Mission</h2>
            <p className="mt-2 text-sm leading-relaxed text-gray-600">
              To be Pakistan's most trusted electronics retailer by offering genuine products,
              transparent pricing and a shopping experience that keeps customers coming back.
            </p>
          </div>
          <div className="rounded-2xl bg-white p-8 shadow-card ring-1 ring-gray-100">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-navy-700 text-white">
              <Eye className="h-5 w-5" />
            </span>
            <h2 className="mt-4 text-xl font-bold text-navy-900">Our Vision</h2>
            <p className="mt-2 text-sm leading-relaxed text-gray-600">
              A future where every Pakistani has seamless access to the technology that powers
              work, study and play — delivered fast, backed by warranty.
            </p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-gray-50 py-14">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-center text-2xl font-bold text-navy-900 sm:text-3xl">What we stand for</h2>
          <p className="mx-auto mt-2 max-w-xl text-center text-sm text-gray-500">
            The values that guide every product we list and every order we pack.
          </p>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v) => (
              <div key={v.title} className="rounded-2xl bg-white p-6 shadow-card ring-1 ring-gray-100 transition hover:-translate-y-1 hover:shadow-card-hover">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-blue-50 text-brand-600">
                  <v.icon className="h-5 w-5" />
                </span>
                <h3 className="mt-4 text-base font-semibold text-navy-900">{v.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-gray-600">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-14">
        <div className="rounded-3xl bg-gradient-to-br from-brand-600 to-navy-700 px-6 py-12 text-center sm:px-12">
          <h2 className="text-2xl font-bold text-white sm:text-3xl">Ready to upgrade your tech?</h2>
          <p className="mx-auto mt-3 max-w-md text-sm text-blue-100">
            Explore our full range of smartphones, laptops, audio and gaming gear.
          </p>
          <button
            onClick={() => navigateTo({ name: 'shop' })}
            className="mt-6 rounded-xl bg-white px-6 py-3 text-sm font-semibold text-navy-900 transition hover:bg-blue-50"
          >
            Start shopping
          </button>
        </div>
      </section>
    </div>
  );
}
