import { useState } from 'react';
import { ArrowRight, Check, CreditCard, Banknote, Truck, Info, ShieldCheck } from 'lucide-react';
import { useStore } from '../store';
import { getProduct, formatPKR } from '../data';
import { useRoute } from '../router';

const SHIPPING_FEE = 500;
const SHIPPING_THRESHOLD = 25000;

type PaymentMethod = 'cod' | 'card' | 'transfer';

interface FormState {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  postal: string;
  payment: PaymentMethod;
}

export function CheckoutPage() {
  const [route, navigate] = useRoute();
  const { cart, cartSubtotal, clearCart } = useStore();
  const [form, setForm] = useState<FormState>({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postal: '',
    payment: 'cod',
  });
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [placed, setPlaced] = useState(false);

  const shipping = cartSubtotal >= SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  const total = cartSubtotal + shipping;

  if (cart.length === 0 && !placed) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-navy-900">Your cart is empty</h1>
        <p className="mt-2 text-gray-500">Add some products before checking out.</p>
        <button
          onClick={() => navigate({ name: 'shop' })}
          className="mt-6 rounded-xl bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-500"
        >
          Go to shop
        </button>
      </div>
    );
  }

  if (placed) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20">
        <div className="rounded-3xl bg-white p-10 text-center shadow-card ring-1 ring-gray-100 animate-scale-in">
          <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-emerald-100 text-emerald-600">
            <Check className="h-10 w-10" />
          </div>
          <h1 className="mt-6 text-2xl font-bold text-navy-900">Order placed successfully!</h1>
          <p className="mt-3 text-sm text-gray-600">
            Thank you, <span className="font-semibold">{form.name}</span>. A confirmation has been sent
            to <span className="font-semibold">{form.email}</span>. This is a demonstration checkout — no
            payment has been processed and no real order has been placed.
          </p>
          <div className="mt-6 rounded-xl bg-gray-50 p-4 text-left text-sm">
            <div className="flex justify-between py-1">
              <span className="text-gray-500">Order number</span>
              <span className="font-semibold text-navy-900">
                #TN-{Math.floor(100000 + Math.random() * 900000)}
              </span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-gray-500">Delivery to</span>
              <span className="font-medium text-navy-900">{form.city || 'Pakistan'}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-gray-500">Total</span>
              <span className="font-bold text-brand-600">{formatPKR(total)}</span>
            </div>
          </div>
          <button
            onClick={() => navigate({ name: 'home' })}
            className="mt-6 rounded-xl bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-500"
          >
            Back to home
          </button>
        </div>
      </div>
    );
  }

  const update = (field: keyof FormState, value: string) => {
    setForm((f) => ({ ...f, [field]: value }));
    setErrors((e) => ({ ...e, [field]: undefined }));
  };

  const validate = (): boolean => {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (!form.name.trim()) next.name = 'Please enter your full name';
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      next.email = 'Enter a valid email address';
    if (!/^\+?\d[\d\s-]{7,}$/.test(form.phone)) next.phone = 'Enter a valid phone number';
    if (!form.address.trim()) next.address = 'Please enter your street address';
    if (!form.city.trim()) next.city = 'Please enter your city';
    if (!/^\d{4,6}$/.test(form.postal)) next.postal = 'Enter a valid postal code';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setPlaced(true);
      clearCart();
      window.scrollTo({ top: 0 });
    }, 900);
  };

  const inputClass = (field: keyof FormState) =>
    `w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition focus:ring-2 ${
      errors[field]
        ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-100'
        : 'border-gray-200 focus:border-brand-400 focus:ring-brand-100'
    }`;

  return (
    <div className="bg-gray-50 min-h-[60vh]">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <h1 className="text-2xl font-bold text-navy-900 sm:text-3xl">Checkout</h1>
        <div className="mt-2 flex items-center gap-2 rounded-xl bg-amber-50 px-4 py-2.5 text-xs text-amber-800 ring-1 ring-amber-200">
          <Info className="h-4 w-4 shrink-0" />
          This is a demonstration checkout. No real payment is processed and no order is shipped.
        </div>

        <form onSubmit={handleSubmit} className="mt-6 grid gap-6 lg:grid-cols-3">
          {/* Form fields */}
          <div className="space-y-6 lg:col-span-2">
            {/* Contact */}
            <section className="rounded-2xl bg-white p-6 shadow-card ring-1 ring-gray-100">
              <h2 className="text-base font-bold text-navy-900">Contact details</h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">Full name</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => update('name', e.target.value)}
                    placeholder="Ali Khan"
                    className={inputClass('name')}
                  />
                  {errors.name && <p className="mt-1 text-xs text-rose-500">{errors.name}</p>}
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">Email</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => update('email', e.target.value)}
                    placeholder="you@email.com"
                    className={inputClass('email')}
                  />
                  {errors.email && <p className="mt-1 text-xs text-rose-500">{errors.email}</p>}
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">Phone number</label>
                  <input
                    type="tel"
                    value={form.phone}
                    onChange={(e) => update('phone', e.target.value)}
                    placeholder="+92 300 1234567"
                    className={inputClass('phone')}
                  />
                  {errors.phone && <p className="mt-1 text-xs text-rose-500">{errors.phone}</p>}
                </div>
              </div>
            </section>

            {/* Address */}
            <section className="rounded-2xl bg-white p-6 shadow-card ring-1 ring-gray-100">
              <h2 className="text-base font-bold text-navy-900">Delivery address</h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">Street address</label>
                  <input
                    type="text"
                    value={form.address}
                    onChange={(e) => update('address', e.target.value)}
                    placeholder="House 12, Street 3, Block C"
                    className={inputClass('address')}
                  />
                  {errors.address && <p className="mt-1 text-xs text-rose-500">{errors.address}</p>}
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">City</label>
                  <input
                    type="text"
                    value={form.city}
                    onChange={(e) => update('city', e.target.value)}
                    placeholder="Lahore"
                    className={inputClass('city')}
                  />
                  {errors.city && <p className="mt-1 text-xs text-rose-500">{errors.city}</p>}
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">Postal code</label>
                  <input
                    type="text"
                    value={form.postal}
                    onChange={(e) => update('postal', e.target.value)}
                    placeholder="54000"
                    className={inputClass('postal')}
                  />
                  {errors.postal && <p className="mt-1 text-xs text-rose-500">{errors.postal}</p>}
                </div>
              </div>
            </section>

            {/* Payment */}
            <section className="rounded-2xl bg-white p-6 shadow-card ring-1 ring-gray-100">
              <h2 className="text-base font-bold text-navy-900">Payment method</h2>
              <div className="mt-4 space-y-3">
                {[
                  { id: 'cod' as const, label: 'Cash on Delivery', icon: Banknote, sub: 'Pay when your order arrives' },
                  { id: 'card' as const, label: 'Credit / Debit Card', icon: CreditCard, sub: 'Visa, Mastercard (demo)' },
                  { id: 'transfer' as const, label: 'Bank Transfer', icon: Truck, sub: 'Transfer in advance (demo)' },
                ].map((opt) => {
                  const active = form.payment === opt.id;
                  return (
                    <label
                      key={opt.id}
                      className={`flex cursor-pointer items-center gap-4 rounded-xl border p-4 transition ${
                        active ? 'border-brand-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <span
                        className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 ${
                          active ? 'border-brand-600' : 'border-gray-300'
                        }`}
                      >
                        {active && <span className="h-2.5 w-2.5 rounded-full bg-brand-600" />}
                      </span>
                      <input
                        type="radio"
                        name="payment"
                        value={opt.id}
                        checked={active}
                        onChange={() => update('payment', opt.id)}
                        className="sr-only"
                      />
                      <opt.icon className={`h-5 w-5 ${active ? 'text-brand-600' : 'text-gray-400'}`} />
                      <div>
                        <div className="text-sm font-semibold text-navy-900">{opt.label}</div>
                        <div className="text-xs text-gray-500">{opt.sub}</div>
                      </div>
                    </label>
                  );
                })}
              </div>
            </section>
          </div>

          {/* Order summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-28 rounded-2xl bg-white p-6 shadow-card ring-1 ring-gray-100">
              <h2 className="text-base font-bold text-navy-900">Order summary</h2>
              <div className="mt-4 max-h-64 space-y-3 overflow-y-auto pr-1">
                {cart.map((item) => {
                  const product = getProduct(item.productId);
                  if (!product) return null;
                  return (
                    <div key={item.productId} className="flex items-center gap-3">
                      <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-gray-50">
                        <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
                        <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-navy-900 px-1 text-[10px] font-bold text-white">
                          {item.quantity}
                        </span>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-semibold text-navy-900">{product.name}</p>
                        <p className="text-xs text-gray-400">{formatPKR(product.price)}</p>
                      </div>
                      <span className="text-xs font-semibold text-navy-900">
                        {formatPKR(product.price * item.quantity)}
                      </span>
                    </div>
                  );
                })}
              </div>

              <dl className="mt-5 space-y-2.5 border-t border-gray-100 pt-4 text-sm">
                <div className="flex justify-between">
                  <dt className="text-gray-500">Subtotal</dt>
                  <dd className="font-medium text-navy-900">{formatPKR(cartSubtotal)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-500">Delivery</dt>
                  <dd className="font-medium text-navy-900">
                    {shipping === 0 ? <span className="text-emerald-600">Free</span> : formatPKR(shipping)}
                  </dd>
                </div>
                <div className="flex justify-between border-t border-gray-100 pt-3">
                  <dt className="text-base font-bold text-navy-900">Total</dt>
                  <dd className="text-base font-bold text-brand-600">{formatPKR(total)}</dd>
                </div>
              </dl>

              <button
                type="submit"
                disabled={submitting}
                className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 py-3.5 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 transition hover:bg-brand-500 disabled:opacity-60"
              >
                {submitting ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                    Placing order...
                  </>
                ) : (
                  <>
                    Place order <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>

              <div className="mt-4 flex items-center justify-center gap-1.5 text-xs text-gray-400">
                <ShieldCheck className="h-3.5 w-3.5" /> Secure demo checkout
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
