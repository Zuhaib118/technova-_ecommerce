import { Cpu } from 'lucide-react';
import { navigateTo } from '../router';
import { categories } from '../data';
import type { CategoryId } from '../types';

interface Props {
  image: string;
  name: string;
  id: CategoryId;
}

export function CategoryCard({ image, name, id }: Props) {
  return (
    <button
      onClick={() => navigateTo({ name: 'shop', category: id })}
      className="group relative flex flex-col items-center justify-end overflow-hidden rounded-2xl ring-1 ring-gray-200 transition-all duration-300 hover:ring-blue-300 hover:shadow-lg aspect-[4/5] bg-gray-100"
    >
      <img
        src={image}
        alt={name}
        loading="lazy"
        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-navy-900/80 via-navy-900/10 to-transparent" />
      <div className="relative z-10 w-full p-4 text-left">
        <h3 className="text-base font-semibold text-white drop-shadow">{name}</h3>
        <span className="mt-1 inline-flex items-center gap-1 text-xs font-medium text-blue-200 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          Shop now <Cpu className="h-3 w-3" />
        </span>
      </div>
    </button>
  );
}

export function CategoryGrid() {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7">
      {categories.map((c) => (
        <CategoryCard key={c.id} image={c.image} name={c.name} id={c.id} />
      ))}
    </div>
  );
}
