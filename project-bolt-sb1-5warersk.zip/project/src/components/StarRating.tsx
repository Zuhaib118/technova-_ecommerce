interface Props {
  rating: number;
  reviews?: number;
  size?: 'sm' | 'md';
}

import { Star } from 'lucide-react';

export function StarRating({ rating, reviews, size = 'sm' }: Props) {
  const dim = size === 'sm' ? 'h-3.5 w-3.5' : 'h-4 w-4';
  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center">
        {Array.from({ length: 5 }).map((_, i) => {
          const fill = Math.max(0, Math.min(1, rating - i));
          return (
            <span key={i} className="relative inline-block">
              <Star className={`${dim} text-gray-300`} />
              <span
                className="absolute inset-0 overflow-hidden"
                style={{ width: `${fill * 100}%` }}
              >
                <Star className={`${dim} fill-amber-400 text-amber-400`} />
              </span>
            </span>
          );
        })}
      </div>
      <span className="text-xs font-medium text-gray-600">{rating.toFixed(1)}</span>
      {reviews !== undefined && (
        <span className="text-xs text-gray-400">({reviews})</span>
      )}
    </div>
  );
}
