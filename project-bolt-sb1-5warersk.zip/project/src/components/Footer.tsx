import { Cpu, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';
import { categories } from '../data';
import { navigateTo } from '../router';

export function Footer() {
  return (
    <footer className="mt-16 bg-navy-900 text-gray-300">
      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-brand-500 to-navy-600 text-white">
                <Cpu className="h-5 w-5" />
              </span>
              <span className="text-lg font-bold text-white">
                Tech<span className="text-brand-400">Nova</span>
              </span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-gray-400">
              TechNova brings you the latest electronics at honest prices — smartphones,
              laptops, audio and gaming gear, delivered across Pakistan.
            </p>
            <div className="mt-5 flex items-center gap-3">
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="grid h-9 w-9 place-items-center rounded-lg bg-navy-800 text-gray-400 transition hover:bg-brand-600 hover:text-white"
                  aria-label="Social link"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide text-white">Categories</h4>
            <ul className="mt-4 space-y-2.5 text-sm">
              {categories.slice(0, 5).map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => navigateTo({ name: 'shop', category: c.id })}
                    className="text-gray-400 transition hover:text-white"
                  >
                    {c.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide text-white">Support</h4>
            <ul className="mt-4 space-y-2.5 text-sm">
              <li><button onClick={() => navigateTo({ name: 'about' })} className="text-gray-400 hover:text-white">About Us</button></li>
              <li><button onClick={() => navigateTo({ name: 'contact' })} className="text-gray-400 hover:text-white">Contact Us</button></li>
              <li><button onClick={() => navigateTo({ name: 'faq' })} className="text-gray-400 hover:text-white">FAQ</button></li>
              <li><button onClick={() => navigateTo({ name: 'shop' })} className="text-gray-400 hover:text-white">Shop All</button></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide text-white">Get in touch</h4>
            <ul className="mt-4 space-y-3 text-sm text-gray-400">
              <li className="flex items-start gap-2.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
                <span>Main Boulevard, Gulberg III, Lahore, Pakistan</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 shrink-0 text-brand-400" />
                <span>+92 300 1234567</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 shrink-0 text-brand-400" />
                <span>support@technova.pk</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-navy-800 pt-6">
          <div className="flex flex-col items-center justify-between gap-3 text-xs text-gray-500 sm:flex-row">
            <p>&copy; {new Date().getFullYear()} TechNova. All rights reserved. This is a demo store for educational purposes.</p>
            <p>Designed for a university web development project.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
