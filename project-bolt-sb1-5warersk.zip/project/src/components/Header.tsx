import { useEffect, useState } from 'react';
import {
  Search,
  ShoppingCart,
  Heart,
  Menu,
  X,
  Cpu,
  ChevronDown,
} from 'lucide-react';
import { categories } from '../data';
import { navigateTo, useRoute } from '../router';
import { useStore } from '../store';

export function Header() {
  const [route, navigate] = useRoute();
  const { cartCount, wishlist } = useStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [route]);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate({ name: 'shop', query: query.trim() });
      setSearchOpen(false);
    }
  };

  const go = (r: Parameters<typeof navigate>[0]) => {
    navigate(r);
  };

  return (
    <>
      {/* Top announcement bar */}
      <div className="bg-navy-900 text-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2 text-xs">
          <span className="hidden sm:block">Free delivery on orders over Rs 25,000 across Pakistan</span>
          <span className="sm:hidden">Free delivery over Rs 25,000</span>
          <div className="flex items-center gap-4">
            <button onClick={() => go({ name: 'about' })} className="hover:text-blue-200">About</button>
            <button onClick={() => go({ name: 'contact' })} className="hover:text-blue-200">Contact</button>
            <button onClick={() => go({ name: 'faq' })} className="hover:text-blue-200">FAQ</button>
          </div>
        </div>
      </div>

      <header
        className={`sticky top-0 z-50 bg-white transition-shadow ${
          scrolled ? 'shadow-md' : 'shadow-sm'
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3.5">
          {/* Logo */}
          <button
            onClick={() => go({ name: 'home' })}
            className="flex shrink-0 items-center gap-2"
          >
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-brand-500 to-navy-700 text-white">
              <Cpu className="h-5 w-5" />
            </span>
            <span className="text-lg font-bold tracking-tight text-navy-900">
              Tech<span className="text-brand-600">Nova</span>
            </span>
          </button>

          {/* Desktop search */}
          <form
            onSubmit={submitSearch}
            className="relative hidden flex-1 md:block"
          >
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search for smartphones, laptops, headphones..."
              className="w-full rounded-xl border border-gray-200 bg-gray-50 py-2.5 pl-11 pr-4 text-sm text-gray-800 outline-none transition focus:border-brand-400 focus:bg-white focus:ring-2 focus:ring-brand-100"
            />
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-gray-400" />
          </form>

          {/* Right actions */}
          <div className="ml-auto flex items-center gap-1.5">
            <button
              onClick={() => setSearchOpen((v) => !v)}
              className="grid h-10 w-10 place-items-center rounded-lg text-navy-800 hover:bg-gray-100 md:hidden"
              aria-label="Search"
            >
              <Search className="h-5 w-5" />
            </button>
            <button
              onClick={() => go({ name: 'wishlist' })}
              className="relative grid h-10 w-10 place-items-center rounded-lg text-navy-800 hover:bg-gray-100"
              aria-label="Wishlist"
            >
              <Heart className="h-5 w-5" />
              {wishlist.length > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
                  {wishlist.length}
                </span>
              )}
            </button>
            <button
              onClick={() => go({ name: 'cart' })}
              className="relative grid h-10 w-10 place-items-center rounded-lg text-navy-800 hover:bg-gray-100"
              aria-label="Cart"
            >
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-brand-600 px-1 text-[10px] font-bold text-white">
                  {cartCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileOpen((v) => !v)}
              className="grid h-10 w-10 place-items-center rounded-lg text-navy-800 hover:bg-gray-100 lg:hidden"
              aria-label="Menu"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile search */}
        {searchOpen && (
          <div className="border-t border-gray-100 px-4 py-3 md:hidden">
            <form onSubmit={submitSearch} className="relative">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search products..."
                className="w-full rounded-xl border border-gray-200 bg-gray-50 py-2.5 pl-11 pr-4 text-sm outline-none focus:border-brand-400 focus:bg-white"
                autoFocus
              />
              <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-gray-400" />
            </form>
          </div>
        )}

        {/* Desktop category nav */}
        <nav className="hidden border-t border-gray-100 bg-white lg:block">
          <div className="mx-auto flex max-w-7xl items-center gap-1 px-4">
            <button
              onClick={() => go({ name: 'shop' })}
              className="flex items-center gap-1 px-3 py-3 text-sm font-medium text-navy-800 transition hover:text-brand-600"
            >
              All Products <ChevronDown className="h-3.5 w-3.5" />
            </button>
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => go({ name: 'shop', category: c.id })}
                className="px-3 py-3 text-sm font-medium text-navy-800 transition hover:text-brand-600"
              >
                {c.name}
              </button>
            ))}
          </div>
        </nav>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="border-t border-gray-100 bg-white lg:hidden">
            <div className="max-h-[70vh] overflow-y-auto px-4 py-3">
              <button
                onClick={() => go({ name: 'shop' })}
                className="block w-full rounded-lg px-3 py-2.5 text-left text-sm font-semibold text-navy-900 hover:bg-gray-50"
              >
                All Products
              </button>
              {categories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => go({ name: 'shop', category: c.id })}
                  className="block w-full rounded-lg px-3 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  {c.name}
                </button>
              ))}
              <div className="my-2 h-px bg-gray-100" />
              <button onClick={() => go({ name: 'about' })} className="block w-full rounded-lg px-3 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50">About Us</button>
              <button onClick={() => go({ name: 'contact' })} className="block w-full rounded-lg px-3 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50">Contact Us</button>
              <button onClick={() => go({ name: 'faq' })} className="block w-full rounded-lg px-3 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50">FAQ</button>
            </div>
          </div>
        )}
      </header>
    </>
  );
}

export { navigateTo };
