import { Heart, ShoppingCart, Eye } from 'lucide-react';
import type { Product } from '../types';
import { formatPKR } from '../data';
import { navigateTo } from '../router';
import { useStore } from '../store';
import { useToast } from './Toast';
import { StarRating } from './StarRating';

interface Props {
  product: Product;
  index?: number;
}

export function ProductCard({ product, index = 0 }: Props) {
  const { addToCart, toggleWishlist, isWishlisted } = useStore();
  const { notify } = useToast();
  const wished = isWishlisted(product.id);

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.inStock) return;
    addToCart(product.id);
    notify(`${product.name} added to cart`);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
    notify(wished ? 'Removed from wishlist' : 'Added to wishlist', 'info');
  };

  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  return (
    <div
      onClick={() => navigateTo({ name: 'product', id: product.id })}
      className="group flex cursor-pointer flex-col overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-gray-100 transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover animate-fade-up"
      style={{ animationDelay: `${Math.min(index * 60, 400)}ms` }}
    >
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {product.badge && (
            <span className="rounded-full bg-navy-900 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-white">
              {product.badge}
            </span>
          )}
          {discount > 0 && (
            <span className="rounded-full bg-rose-500 px-2.5 py-1 text-[10px] font-semibold text-white">
              -{discount}%
            </span>
          )}
        </div>
        <button
          onClick={handleWishlist}
          aria-label="Toggle wishlist"
          className={`absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full backdrop-blur transition-all ${
            wished
              ? 'bg-rose-500 text-white'
              : 'bg-white/80 text-gray-600 hover:bg-white hover:text-rose-500'
          }`}
        >
          <Heart className={`h-4.5 w-4.5 ${wished ? 'fill-white' : ''}`} />
        </button>
        <div className="absolute inset-x-0 bottom-0 flex translate-y-full items-center justify-center gap-2 bg-gradient-to-t from-navy-900/70 to-transparent p-3 transition-transform duration-300 group-hover:translate-y-0">
          <button
            onClick={handleAdd}
            disabled={!product.inStock}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-white px-3 py-2 text-xs font-semibold text-navy-900 transition hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <ShoppingCart className="h-3.5 w-3.5" />
            {product.inStock ? 'Add to Cart' : 'Out of Stock'}
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigateTo({ name: 'product', id: product.id });
            }}
            aria-label="Quick view"
            className="grid h-8 w-8 place-items-center rounded-lg bg-white/90 text-navy-900 transition hover:bg-blue-50"
          >
            <Eye className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-4">
        <span className="text-[11px] font-medium uppercase tracking-wide text-blue-600">
          {product.brand}
        </span>
        <h3 className="mt-1 text-sm font-semibold leading-snug text-navy-900 line-clamp-2">
          {product.name}
        </h3>
        <div className="mt-2">
          <StarRating rating={product.rating} reviews={product.reviews} />
        </div>
        <div className="mt-auto flex items-end justify-between pt-3">
          <div>
            <span className="text-base font-bold text-navy-900">
              {formatPKR(product.price)}
            </span>
            {product.oldPrice && (
              <span className="ml-1.5 text-xs text-gray-400 line-through">
                {formatPKR(product.oldPrice)}
              </span>
            )}
          </div>
          <span
            className={`text-[11px] font-medium ${
              product.inStock ? 'text-emerald-600' : 'text-rose-500'
            }`}
          >
            {product.inStock ? 'In stock' : 'Out of stock'}
          </span>
        </div>
      </div>
    </div>
  );
}
